<?php

namespace App\Http\Resources\ExaminationType;

use Illuminate\Http\Request;
// use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\SuccessResource;

class ExaminationTypeResource extends SuccessResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'is_promotional_exam' => $this->is_promotional_exam
        ];
    }
}
